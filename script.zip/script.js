/// 1  array
let listaSuper =["Arrosz", "lenteja", "carne", "pollo", 1, 4, [1,2,3],{ "id":2}];

console.log(listaSuper)

console.log(listaSuper[6][1])
console.log(listaSuper[7])

listaSuper. push("vino"); // AGREGA AL FINAL
console.log(listaSuper)

listaSuper.unshift("VODKA") /// AGREGA AL INCIO
console.log(listaSuper)

listaSuper.pop() // alimina al final 

listaSuper.shift() //eliminar al inicio 
 
let Super2 = [2,8, 9, 7]; 
Super2.slice(1,0,3)
console.log(Super2)
 

let Super2 = [2,8, 9, 7]; 
Super2.splice(1,0,3)
console.log(Super2)