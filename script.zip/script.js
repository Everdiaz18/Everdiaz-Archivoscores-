//Desestructuración en objetos anidados
const info = {
    personal: {
        nombre: 'Carlos',
        apellido: 'Vega',
        detalles: {
            edad: 30,
            ocupacion: 'Ingeniero'
        }
    }
};

const { personal: { detalles: { edad, salario } } } = info;
console.log(edad);  // Predicción :30
console.log(salario);  // Predicción: undefined
// Salida obtenida: 
//    30
//    undefined
// Explicación:
//     La desestructuración extrae la propiedad 'edad' del objeto anidado 'detalles'
//     La propiedad 'salario' no existe en el objeto, por lo que devuelve undefined
//     La sintaxis de desestructuración anidada permite acceder a propiedades profundas sin necesidad de múltiples accesos con punto


// Uso del operador spread en la fusión de objetos 
const objetoA = { a: 1, b: 2, c: 3 };
const objetoB = { b: 4, c: 5, d: 6 };
const resultado = { ...objetoA, ...objetoB };
console.log(resultado); // Predicción: { a: 1, b: 4, c: 5, d: 6 }
// Salida obtenida: { a: 1, b: 4, c: 5, d: 6 }
// Explicación:
//   El operador spread (...) expande las propiedades de los objetos
//   Cuando hay propiedades con el mismo nombre, el último objeto sobrescribe las anteriores
//   El orden importa: objetoB se expande después de objetoA, por lo que sus propiedades prevalecen en caso de conflicto de nombres
//   El resultado es la fusión 


// Ámbito de variables en funciones y bloques
const verificar = () => {
    if (true) {
        const a = 2;
        let b = 3;
        var c = 4;
    }
    console.log(c); // Predicción: 4 
    console.log(a); // Predicción: ReferenceError: a is not defined
    console.log(b); // Predicción: ReferenceError: b is not defined
}
verificar();

//  Salida obtenida:
//    4
//    ReferenceError: a is not defined
// Explicación:
//    VAR: Tiene ámbito de función, por lo que 'c' es accesible en toda la función verificar()
//    CONST y LET: Tienen ámbito de bloque, por lo que 'a' y 'b' solo existen dentro del bloque if
//    El error se detiene en el primer console.log(a), por lo que console.log(b) nunca se ejecuta



// Propiedades de objetos inmutables
const datos = Object.freeze({ nombre: 'Luis', edad: 29 });
datos.edad = 30;
console.log(datos.edad); //Predicción:   
//  El intento de modificación datos.edad = 30 fallará silenciosamente en modo estricto
//  En modo no estricto, la asignación no tendrá efecto
// Salida obtenida: 29
// Explicación:
//    Object.freeze() hace que el objeto sea completamente inmutable
//    No se pueden agregar, eliminar o modificar propiedades
//    En modo estricto ('use strict'), intentar modificar un objeto congelado lanza un error
//    En modo no estricto (por defecto en muchos entornos), la asignación falla silenciosamente



// Manipulación de arreglos sin modificar el original
const original = [1, 2, 3];
const nuevo = original.concat(4);
console.log(original); //Predicción: [1, 2, 3]
console.log(nuevo); //Predicción:[1, 2, 3, 4]
// Salida obtenida:
//    [1, 2, 3]
//    [1, 2, 3, 4]
// Explicación:
//    El método concat() NO modifica el array original
//    Retorna un NUEVO array con los elementos del original más los nuevos elementos
//    El array original permanece intacto e inmutable



// Acceso a elementos de un arreglo con destructuración
const frutas = ['manzana', 'naranja', 'pera', 'mango'];
const [primera, segunda] = frutas;
console.log(primera);  // Predicción: manzana
console.log(segunda);  // Predicción: naranja
// Salida obtenida:
//    manzana
//    naranja
// Explicación:
//   La desestructuración de arrays extrae elementos por posición/índice
//   Primera corresponde al índice 0: 'manzana'
//   Segunda corresponde al índice 1: 'naranja'
//   Los elementos restantes ('pera', 'mango') se ignoran



// Comportamiento del ámbito de let en bucles anidados 
for (let i = 0; i < 3; i++) {
    for (let i = 0; i < 2; i++) {
        console.log(i);
    }
}

// Predicción:
//  El bucle externo se ejecutará 3 veces (i = 0, 1, 2)
//  Por cada iteración del bucle externo, el bucle interno se ejecutará 2 veces
//  Cada bucle interno imprimirá: 0, 1
// Salida obtenida:
//    0
//    1
//    0
//    1
//    0
//    1
// Exolicación:
//   let tiene ámbito de BLOQUE, no de función
//   Cada bucle crea su PROPIO ámbito de variable 'i'
//   La 'i' del bucle interno es DIFERENTE de la 'i' del bucle externo
//   No hay conflicto de nombres porque están en bloques diferentes



// Uso del operador spread para combinar arreglos
const numeros1 = [1, 2, 3];
const numeros2 = [3, 4, 5];
const combinados = [...numeros1, ...numeros2];
console.log(combinados);

// Predicción:
//   combinados será: [1, 2, 3, 3, 4, 5]
//   Los arrays se concatenan manteniendo el orden
//    Los elementos duplicados (3) se mantienen
// Salida obtenida:
//    [1, 2, 3, 3, 4, 5]
// Explicación:
//   El operador spread (...) expande los elementos de cada array
//   Crea un NUEVO array (no modifica los originales)
//    Mantiene todos los elementos, incluidos los duplicados
//    Preserva el orden de los elementos según se expanden



// Alcance y captura de variables dentro de una función
const demostracion = () => {
    var nombre = 'Ana';
    let edad = 25;
    if (true) {
        var nombre = 'Luis';
        let edad = 30;
    }
    console.log(nombre);//  Predición: 'Luis' (var tiene function scope)
    console.log(edad);//  Predicción: 25 (let tiene block scope)
}
demostracion();

// Salida obtenida:
//    Luis
//    25
// Explicación:
//   VAR: Tiene ámbito de función, la reasignación dentro del if afecta la variable exterior
//   LET: Tiene ámbito de bloque, la variable dentro del if es diferente a la exterior